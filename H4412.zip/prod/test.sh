#!/bin/bash
(cd tests && ./mktest.sh)
