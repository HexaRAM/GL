#include "declaration.h"

void Declaration::print(ostream& os) const {
	//TODO
}