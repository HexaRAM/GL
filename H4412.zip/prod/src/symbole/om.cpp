#include "om.h"

om::om(string t): Symbole(11) {
	type = t;
}