#include "instruction.h"

void Instruction::print(ostream& os) const {
	// Instruction anonyme
}