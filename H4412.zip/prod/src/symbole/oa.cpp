#include "oa.h"

oa::oa(string t): Symbole(10) {
	type = t;
}