#include "unknown.h"

void Unknown::print(ostream& os) const
{
    os << valeur;
}